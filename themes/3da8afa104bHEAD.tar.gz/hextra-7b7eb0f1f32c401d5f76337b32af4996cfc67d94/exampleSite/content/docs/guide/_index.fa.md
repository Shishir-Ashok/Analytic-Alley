---
title: راهنما
weight: 2
prev: /docs/getting-started
next: /docs/guide/organize-files
sidebar:
  open: true
---

برای یادگیری نحوه استفاده از هگزترا، بخش‌های زیر را کاوش کنید:

<!--more-->

{{< cards >}}
  {{< card link="organize-files" title="سازماندهی پرونده‌ها" icon="document-duplicate" >}}
  {{< card link="configuration" title="پیکربندی" icon="adjustments" >}}
  {{< card link="markdown" title="مارک‌داون" icon="markdown" >}}
  {{< card link="syntax-highlighting" title="برجسته‌کردن سینتکس" icon="sparkles" >}}
  {{< card link="latex" title="LaTeX" icon="variable" >}}
  {{< card link="diagrams" title="نمودارها" icon="chart-square-bar" >}}
  {{< card link="shortcodes" title="کدهای کوتاه" icon="template" >}}
  {{< card link="deploy-site" title="به‌کاراندازی سایت" icon="server" >}}
{{< /cards >}}
