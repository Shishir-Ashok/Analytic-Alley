---
linkTitle: پیشرفته
title: موضوعات پیشرفته
prev: /docs/guide/shortcodes/steps
next: /docs/advanced/multi-language
---

این بخش برخی از موضوعات پیشرفته تم را پوشش می‌دهد.

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="چند زبانه" icon="translate" >}}
  {{< card link="customization" title="سفارشی‌سازی" icon="pencil" >}}
  {{< card link="comments" title="سیستم نظردهی" icon="chat-alt" >}}
{{< /cards >}}
